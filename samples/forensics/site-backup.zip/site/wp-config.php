<?php
// Practice sample: fake values only.
define('DB_NAME', 'northwind');
define('DB_USER', 'practice');
define('DB_PASSWORD', 'not-a-real-secret');
